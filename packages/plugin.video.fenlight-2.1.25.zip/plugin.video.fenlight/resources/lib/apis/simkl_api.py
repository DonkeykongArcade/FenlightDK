# -*- coding: utf-8 -*-
import time
import requests
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils
logger = kodi_utils.logger


class SimklAPI:
	BASE = 'https://api.simkl.com'

	def __init__(self):
		self.client_id = get_setting('fenlight.simkl.client_id', 'empty_setting')
		self.access_token = get_setting('fenlight.simkl.token', 'empty_setting')

	def _headers(self, with_auth=False):
		headers = {'Content-Type': 'application/json', 'simkl-api-key': self.client_id}
		if with_auth and self.access_token not in (None, 'empty_setting', ''):
			headers['Authorization'] = 'Bearer %s' % self.access_token
		return headers

	def _get(self, endpoint, params=None, with_auth=False):
		try:
			url = '%s%s' % (self.BASE, endpoint)
			if params is None:
				params = {}
			params['client_id'] = self.client_id
			response = requests.get(url, params=params, headers=self._headers(with_auth=with_auth), timeout=20)
			response.raise_for_status()
			return response.json()
		except Exception as e:
			logger('Simkl Error', str(e))
			return None

	def trending_movies(self):
		return self._get('/movies/trending/', params={'extended': 'full,tmdb'})

	def trending_shows(self):
		return self._get('/tv/trending/', params={'extended': 'full,tmdb'})

	def popular_movies(self):
		return self._get('/movies/popular/', params={'extended': 'full,tmdb'})

	def popular_shows(self):
		return self._get('/tv/popular/', params={'extended': 'full,tmdb'})

	def search_movies(self, query):
		return self._get('/search/movie/', params={'q': query, 'extended': 'full,tmdb'})

	def search_shows(self, query):
		return self._get('/search/tv/', params={'q': query, 'extended': 'full,tmdb'})

	def watchlist(self):
		return self._get('/sync/all-items/', params={'extended': 'full'}, with_auth=True)

	def auth(self):
		try:
			if self.client_id in (None, 'empty_setting', ''):
				kodi_utils.notification('Please set a valid Simkl Client ID')
				return False
			url = '%s/oauth/pin' % self.BASE
			response = requests.post(url, params={'client_id': self.client_id},
									headers={'Content-Type': 'application/json', 'simkl-api-key': self.client_id},
									timeout=20)
			response.raise_for_status()
			pin_data = response.json()
			user_pin = pin_data.get('user_code') or pin_data.get('pin')
			user_url = pin_data.get('user_url', 'https://simkl.com/pin')
			expires_in = pin_data.get('expires_in', 300)
			interval = pin_data.get('interval', 5)
			content = 'Visit [B]%s[/B][CR]and enter PIN: [B]%s[/B]' % (user_url, user_pin)
			progress_dialog = kodi_utils.progress_dialog('Simkl Authorize', '')
			progress_dialog.update(content, 0)
			try:
				poll_url = '%s/oauth/pin/%s/%s' % (self.BASE, self.client_id, user_pin)
				poll_params = {'client_id': self.client_id}
				start = time.time()
				max_polls = 60
				for _ in range(max_polls):
					if progress_dialog.iscanceled():
						break
					kodi_utils.sleep(interval * 1000)
					time_passed = time.time() - start
					progress = int(100 * time_passed / expires_in)
					progress_dialog.update(content, min(progress, 99))
					try:
						poll_response = requests.get(poll_url, params=poll_params,
													headers={'Content-Type': 'application/json', 'simkl-api-key': self.client_id},
													timeout=20)
						if poll_response.status_code == 200:
							result = poll_response.json()
							if result.get('result') == 'OK' and result.get('access_token'):
								set_setting('simkl.token', result['access_token'])
								try: progress_dialog.close()
								except: pass
								kodi_utils.notification('Simkl Authorized', 3000)
								return True
					except Exception as e:
						logger('Simkl Poll Error', str(e))
					if time_passed >= expires_in:
						break
			except: pass
			try: progress_dialog.close()
			except: pass
		except Exception as e:
			logger('Simkl Auth Error', str(e))
		kodi_utils.notification('Simkl Auth Failed', 3000)
		return False

	def revoke(self):
		set_setting('simkl.token', 'empty_setting')
		kodi_utils.notification('Simkl Authorization Revoked', 3000)
