# -*- coding: utf-8 -*-
import sys
import json
from threading import Thread
from modules import kodi_utils
from modules.source_utils import supported_video_extensions
from modules.utils import clean_file_name, normalize

# Maps debrid service token keys to display names and icon names
_SERVICES = [
	{'key': 'rd',  'label': 'RD',  'icon': 'realdebrid'},
	{'key': 'pm',  'label': 'PM',  'icon': 'premiumize'},
	{'key': 'ad',  'label': 'AD',  'icon': 'alldebrid'},
	{'key': 'tb',  'label': 'TB',  'icon': 'torbox'},
]


def _fetch_rd(results):
	try:
		from apis.real_debrid_api import RealDebrid
		cloud = RealDebrid.user_cloud()
		items = [i for i in cloud if i['status'] == 'downloaded']
		for item in items:
			results.append({
				'service_label': 'RD',
				'service_icon': 'realdebrid',
				'name': item['filename'],
				'url_params': {'mode': 'real_debrid.browse_rd_cloud', 'id': item['id']},
			})
	except: pass


def _fetch_pm(results):
	try:
		from apis.premiumize_api import Premiumize
		cloud = Premiumize.user_cloud(None)
		items = cloud.get('content', [])
		for item in items:
			results.append({
				'service_label': 'PM',
				'service_icon': 'premiumize',
				'name': item['name'],
				'url_params': {'mode': 'premiumize.pm_cloud', 'id': item['id']},
			})
	except: pass


def _fetch_ad(results):
	try:
		from apis.alldebrid_api import AllDebrid
		cloud = AllDebrid.user_cloud()['magnets']
		items = [i for i in cloud if i['statusCode'] == 4]
		for item in items:
			results.append({
				'service_label': 'AD',
				'service_icon': 'alldebrid',
				'name': item['filename'],
				'url_params': {
					'mode': 'alldebrid.browse_ad_cloud',
					'id': item['id'],
					'folder': json.dumps(item['links']),
				},
			})
	except: pass


def _fetch_tb(results):
	try:
		from apis.torbox_api import TorBox
		cloud = TorBox.user_cloud()
		t_data = cloud.get('data', [])
		items = [i for i in t_data if i.get('download_finished')]
		for item in items:
			results.append({
				'service_label': 'TB',
				'service_icon': 'torbox',
				'name': item['name'],
				'url_params': {
					'mode': 'torbox.browse_tb_cloud',
					'folder_id': item['id'],
					'media_type': 'torrent',
				},
			})
	except: pass


_FETCHERS = {
	'rd': _fetch_rd,
	'pm': _fetch_pm,
	'ad': _fetch_ad,
	'tb': _fetch_tb,
}


def unified_cloud():
	from modules.settings import authorized_debrid_check

	# Determine which services are authorized
	authorized = [s for s in _SERVICES if authorized_debrid_check(s['key'])]
	if not authorized:
		return kodi_utils.notification('No debrid services connected')

	# Fetch all services in parallel
	all_results = []
	service_results = {s['key']: [] for s in authorized}
	threads = []
	for s in authorized:
		r = service_results[s['key']]
		t = Thread(target=_FETCHERS[s['key']], args=(r,))
		t.daemon = True
		threads.append(t)
		t.start()
	for t in threads:
		t.join()

	# Merge in service order so grouping is consistent
	for s in authorized:
		all_results.extend(service_results[s['key']])

	def _builder():
		fanart = kodi_utils.get_addon_fanart()
		icon_cache = {s['key']: kodi_utils.get_icon(s['icon']) for s in _SERVICES}
		icon_by_label = {'RD': icon_cache['rd'], 'PM': icon_cache['pm'],
		                 'AD': icon_cache['ad'], 'TB': icon_cache['tb']}

		for count, item in enumerate(all_results, 1):
			try:
				svc = item['service_label']
				icon = icon_by_label.get(svc, kodi_utils.get_addon_fanart())
				folder_name = clean_file_name(normalize(item['name'])).upper()
				display = '%02d | [B][%s][/B] | [I]%s[/I]' % (count, svc, folder_name)
				url = kodi_utils.build_url(item['url_params'])
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon,
				                 'fanart': fanart, 'banner': icon})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot(' ')
				yield (url, listitem, True)
			except: pass

	if not all_results:
		return kodi_utils.notification('No cloud items found across connected services')

	handle = int(sys.argv[1])
	kodi_utils.add_items(handle, list(_builder()))
	kodi_utils.set_content(handle, 'files')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.premium')


def unified_cloud_account_summary():
	from modules.settings import authorized_debrid_check
	from datetime import datetime

	kodi_utils.show_busy_dialog()
	body = []
	append = body.append

	# RealDebrid
	if authorized_debrid_check('rd'):
		try:
			from apis.real_debrid_api import RealDebrid
			from modules.utils import datetime_workaround
			info = RealDebrid.account_info()
			expires = datetime_workaround(info['expiration'], '%Y-%m-%dT%H:%M:%S.%fZ')
			days = (expires - datetime.today()).days
			append('[B]Real-Debrid[/B]: %s — %d days remaining' % (info.get('email', ''), days))
		except:
			append('[B]Real-Debrid[/B]: connected (details unavailable)')

	# Premiumize
	if authorized_debrid_check('pm'):
		try:
			from apis.premiumize_api import Premiumize
			info = Premiumize.account_info()
			expires = datetime.fromtimestamp(info['premium_until'])
			days = (expires - datetime.today()).days
			space_gb = float(int(info.get('space_used', 0))) / 1073741824
			append('[B]Premiumize[/B]: %d days remaining | %.1f GB used' % (days, space_gb))
		except:
			append('[B]Premiumize[/B]: connected (details unavailable)')

	# AllDebrid
	if authorized_debrid_check('ad'):
		try:
			from apis.alldebrid_api import AllDebrid
			info = AllDebrid.account_info()['user']
			expires = datetime.fromtimestamp(info['premiumUntil'])
			days = (expires - datetime.today()).days
			status = 'Premium' if info.get('isPremium') else 'Not Active'
			append('[B]AllDebrid[/B]: %s — %d days remaining' % (status, days))
		except:
			append('[B]AllDebrid[/B]: connected (details unavailable)')

	# TorBox
	if authorized_debrid_check('tb'):
		try:
			from apis.torbox_api import TorBox
			plans = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'}
			info = TorBox.account_info()['data']
			plan_name = plans.get(info.get('plan', -1), 'Unknown')
			expires = info.get('premium_expires_at', 'N/A')
			append('[B]TorBox[/B]: %s plan | expires %s' % (plan_name, expires))
		except:
			append('[B]TorBox[/B]: connected (details unavailable)')

	kodi_utils.hide_busy_dialog()

	if not body:
		return kodi_utils.notification('No debrid services connected')

	kodi_utils.show_text('Cloud Account Summary', '\n\n'.join(body), font_size='large')
