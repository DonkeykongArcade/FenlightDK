# -*- coding: utf-8 -*-
import sys
from apis.simkl_api import SimklAPI
from modules import kodi_utils
# logger = kodi_utils.logger

_SETUP_TEXT = ('To use Simkl:[CR]'
			   '1. Register a free app at simkl.com/settings/developer[CR]'
			   '2. Set your Client ID in Settings > Accounts > Simkl')


def _check_client_id():
	"""Return True if client_id is configured, otherwise show dialog and return False."""
	from caches.settings_cache import get_setting
	client_id = get_setting('fenlight.simkl.client_id', 'empty_setting')
	if client_id in (None, 'empty_setting', ''):
		kodi_utils.ok_dialog(heading='Simkl - Setup Required', text=_SETUP_TEXT)
		return False
	return True


def _build_movie_items(data, handle, icon, fanart):
	"""Yield Kodi listitems for a list of Simkl movie dicts."""
	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	items = []
	for entry in data:
		try:
			movie = entry.get('movie') or entry
			title = movie.get('title', '')
			year = movie.get('year', '')
			ids = movie.get('ids', {})
			tmdb_id = ids.get('tmdb')
			if not tmdb_id:
				continue
			label = '[B]%s[/B] (%s)' % (title, year) if year else '[B]%s[/B]' % title
			url_params = {'mode': 'build_movie_list', 'action': 'simkl_item', 'key_id': tmdb_id}
			url = build_url(url_params)
			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
			info_tag = listitem.getVideoInfoTag()
			info_tag.setTitle(title)
			if year:
				try: info_tag.setYear(int(year))
				except: pass
			info_tag.setPlot(' ')
			items.append((url, listitem, False))
		except: pass
	kodi_utils.add_items(handle, items)


def _build_show_items(data, handle, icon, fanart):
	"""Yield Kodi listitems for a list of Simkl show dicts."""
	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	items = []
	for entry in data:
		try:
			show = entry.get('show') or entry
			title = show.get('title', '')
			year = show.get('year', '')
			ids = show.get('ids', {})
			tmdb_id = ids.get('tmdb')
			if not tmdb_id:
				continue
			label = '[B]%s[/B] (%s)' % (title, year) if year else '[B]%s[/B]' % title
			url_params = {'mode': 'build_tvshow_list', 'action': 'simkl_item', 'key_id': tmdb_id}
			url = build_url(url_params)
			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
			info_tag = listitem.getVideoInfoTag()
			info_tag.setTitle(title)
			if year:
				try: info_tag.setYear(int(year))
				except: pass
			info_tag.setPlot(' ')
			items.append((url, listitem, False))
		except: pass
	kodi_utils.add_items(handle, items)


def _finish_directory(handle, content, category):
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, category)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.%s' % content, content)


def simkl_trending_movies(params):
	if not _check_client_id(): return
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	icon = kodi_utils.get_icon('movies')
	try:
		kodi_utils.show_busy_dialog()
		data = SimklAPI().trending_movies() or []
		kodi_utils.hide_busy_dialog()
		_build_movie_items(data, handle, icon, fanart)
	except:
		kodi_utils.hide_busy_dialog()
	_finish_directory(handle, 'movies', 'Simkl Trending Movies')


def simkl_trending_shows(params):
	if not _check_client_id(): return
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	icon = kodi_utils.get_icon('tv')
	try:
		kodi_utils.show_busy_dialog()
		data = SimklAPI().trending_shows() or []
		kodi_utils.hide_busy_dialog()
		_build_show_items(data, handle, icon, fanart)
	except:
		kodi_utils.hide_busy_dialog()
	_finish_directory(handle, 'tvshows', 'Simkl Trending Shows')


def simkl_popular_movies(params):
	if not _check_client_id(): return
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	icon = kodi_utils.get_icon('movies')
	try:
		kodi_utils.show_busy_dialog()
		data = SimklAPI().popular_movies() or []
		kodi_utils.hide_busy_dialog()
		_build_movie_items(data, handle, icon, fanart)
	except:
		kodi_utils.hide_busy_dialog()
	_finish_directory(handle, 'movies', 'Simkl Popular Movies')


def simkl_popular_shows(params):
	if not _check_client_id(): return
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	icon = kodi_utils.get_icon('tv')
	try:
		kodi_utils.show_busy_dialog()
		data = SimklAPI().popular_shows() or []
		kodi_utils.hide_busy_dialog()
		_build_show_items(data, handle, icon, fanart)
	except:
		kodi_utils.hide_busy_dialog()
	_finish_directory(handle, 'tvshows', 'Simkl Popular Shows')


def simkl_my_watchlist(params):
	if not _check_client_id(): return
	from caches.settings_cache import get_setting
	token = get_setting('fenlight.simkl.token', 'empty_setting')
	if token in (None, 'empty_setting', ''):
		kodi_utils.ok_dialog(heading='Simkl - Not Authorized',
							 text='You must authorize your Simkl account first.[CR]Go to Settings > Accounts > Simkl > Authorize.')
		return
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	movie_icon = kodi_utils.get_icon('movies')
	show_icon = kodi_utils.get_icon('tv')
	try:
		kodi_utils.show_busy_dialog()
		data = SimklAPI().watchlist() or {}
		kodi_utils.hide_busy_dialog()
		movies = data.get('movies') or []
		shows = data.get('shows') or []
		_build_movie_items(movies, handle, movie_icon, fanart)
		_build_show_items(shows, handle, show_icon, fanart)
	except:
		kodi_utils.hide_busy_dialog()
	_finish_directory(handle, 'movies', 'Simkl My Watchlist')


def simkl_authenticate(params):
	if not _check_client_id(): return
	SimklAPI().auth()


def simkl_revoke(params):
	SimklAPI().revoke()
